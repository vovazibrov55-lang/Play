# В начале, после extends
var can_move = true        # блокировка движения
var current_trash = null   # ссылка на мусор, с которым взаимодействуем
var interaction_key = "E"  # можно настроить

# В _physics_process добавьте:
func _physics_process(delta):
	# Движение только если can_move == true
	if can_move:
		# Ваш текущий код движения (например, с Input.get_vector)
		var direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
		velocity = direction * speed
		move_and_slide()
	else:
		velocity = Vector2.ZERO   # или оставить без изменений, но остановить
		# (если у вас используется другой способ, закомментируйте перемещение)

	# Проверка нажатия E
	if Input.is_action_just_pressed("interact") and current_trash != null:
		_interact_with_trash()

# Новые методы:

func _interact_with_trash():
	can_move = false
	# Вызываем метод взаимодействия у мусора
	current_trash.interact()
	# Не разблокируем сразу – ждём сигнала от мусора о завершении

# Эти методы вызываются из мусора (через прямые вызовы)
func _on_trash_near(trash):
	if current_trash == null:
		current_trash = trash
		# Показываем подсказку
		UI.show_interact_prompt(true)   # если у вас есть UI автозагрузка

func _on_trash_left(trash):
	if current_trash == trash:
		current_trash = null
		UI.show_interact_prompt(false)

func _on_trash_destroyed(trash):
	# Разблокируем движение после уничтожения мусора
	can_move = true
	if current_trash == trash:
		current_trash = null
	# Подсказку уже скрыли через _on_trash_left, но можно и тут
	UI.show_interact_prompt(false)
